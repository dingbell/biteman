<?php
/**
*url重写
*TYPE 
*	1 /m/a/b-1.html
*	2 index.php/m/a/b-1/c-2
*/
function R($url){
	return rewrite($url);
}
function rewrite($url){
	if(!defined("REWRITE_TYPE")){
		define("REWRITE_TYPE","");
	}
	if(empty($url)) return $url;
	$str="";
	$s=parse_url($url);
	$query=$s['query'];
	parse_str($query,$data);
	switch(REWRITE_TYPE){
		case "pathinfo":
				if(empty($data)) return $s['path'];
				$data['m']=isset($data['m'])?$data['m']:"index";
				$data['a']=isset($data['a'])?$data['a']:"default";
				$str=$s['path']."/".$data['m']."/".$data['a'];
				unset($data['m']);
				unset($data['a']);
				if(!empty($data)){
					foreach($data as $k=>$v){
						 $str.="/$k-$v";
					}
				}
				return $str;		
			break;
		case "rewrite":
				if(empty($data)) return "/index.html";
				$data['m']=isset($data['m'])?$data['m']:"index";
				$data['a']=isset($data['a'])?$data['a']:"default";
				$str="/".$data['m']."/".$data['a'];
				unset($data['m']);
				unset($data['a']);
				if(!empty($data)){
					foreach($data as $k=>$v){
						 $str.="/$k-$v";
					}
				}
				$str.=".html";
				return $str;
			break;
		default:
				return $url;
			break;
		
	}
	
}
/**
*解析pathinfo 路径
*/
function url_get($url){
	if($len=strpos($url,"index.php")!==false){
		$query=preg_replace("/.*index\.php/i","",$url);
		$basename=str_replace($query,"",$url);
		$data=explode("/",$query);
		unset($data[0]);
		if(isset($data[1])){
			$_GET['m']=$data[1];
			unset($data[1]);
		}
		
		if(isset($data[2])){
			$_GET['a']=$data[2];
			unset($data[2]);
		}
		if(!empty($data)){
			foreach($data as $v){
				$c=explode("-",$v);
				if(isset($c[1])){
					$_GET[$c[0]]=$c[1];
				}
			}
		}

	}elseif($len=strpos($url,"module.php")!==false){
		$query=preg_replace("/.*module\.php/i","",$url);
		$basename=str_replace($query,"",$url);
		$data=explode("/",$query);
		unset($data[0]);
		if(isset($data[1])){
			$_GET['m']=$data[1];
			unset($data[1]);
		}
		
		if(isset($data[2])){
			$_GET['a']=$data[2];
			unset($data[2]);
		}
		if(!empty($data)){
			foreach($data as $v){
				$c=explode("-",$v);
				if(isset($c[1])){
					$_GET[$c[0]]=$c[1];
				}
			}
		}
	}
	 
}