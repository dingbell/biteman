<?php
class shop_avgmoney_Model extends model{
	public $db;
	public function __construct($db=false){
		parent::__construct($db);
		$this->table="shop_avgmoney";
	}
}

?>