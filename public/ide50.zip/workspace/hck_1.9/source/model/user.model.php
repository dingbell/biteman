<?php
class user_model extends model{
	public $db;
	function __construct(){
		parent::__construct();
		
	}
}
?>