<?php
class user_bonus_Model extends model{
	public $db;
	public function __construct($db=false){
		parent::__construct($db);
		$this->table="user_bonus";
	}
}

?>