<?php
class shop_paylog_Model extends model{
	public $db;
	public function __construct($db=false){
		parent::__construct($db);
		$this->table="shop_paylog";
	}
}

?>