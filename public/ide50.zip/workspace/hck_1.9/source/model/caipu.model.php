<?php
class caipu_Model extends model{
	public $db;
	function __construct($db=false){
		parent::__construct($db);
		$this->table="caipu";
	}
	
	function catlist($pid=0,$key=0){
		$data=$this->getAll("SELECT * FROM ".table('caipu_cat')." WHERE pid=".intval($pid)." ");
		if($data && $key){
			foreach($data as $k=>$v){
				$catlist[$v['catid']]=$v['cname'];
			}
			return $catlist;
		}
		return $data;
	}
	
	function all_cat(){
		$data=$this->getAll("SELECT * FROM ".table('caipu_cat')."   ");
		if($data ){
			foreach($data as $k=>$v){
				$catlist[$v['catid']]=$v['cname'];
			}
			return $catlist;
		}
	}
	
	
}
?>