<?php
class cai_wei_Model extends model{
	public $db;
	public function __construct($db=false){
		parent::__construct($db);
		$this->table="cai_wei";
	}
}

?>