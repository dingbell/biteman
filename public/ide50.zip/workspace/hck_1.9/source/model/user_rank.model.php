<?php
class user_rank_Model extends model{
	public $db;
	public function __construct($db=false){
		parent::__construct($db);
		$this->table="user_rank";
	}
}

?>