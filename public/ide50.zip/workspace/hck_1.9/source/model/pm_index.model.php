<?php
class pm_index_Model extends model{
	public $db;
	public function __construct($db=false){
		parent::__construct($db);
		$this->table="pm_index";
	}
}

?>