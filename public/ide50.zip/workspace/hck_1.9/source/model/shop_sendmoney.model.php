<?php
class shop_sendmoney_Model extends model{
	public $db;
	public function __construct($db=false){
		parent::__construct($db);
		$this->table="shop_sendmoney";
	}
}

?>