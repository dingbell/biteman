<?php


function shoplist($sql){
	global $db;
	$userid=intval($_SESSION['ssuser']['userid']);
	$shoplist=array();
	$res=$db->query($sql);
	while($rs=$db->fetch_array($res))
	{
		//计算店铺距离
		if($_SESSION['ssuser']['lat']<>0){
				$rs['distance']=distanceByLnglat($_SESSION['ssuser']['lat'],$_SESSION['ssuser']['lng'],$rs['lat'],$rs['lng']);
		}
		$shopconfig=$db->getRow("SELECT * FROM ".table('shopconfig')." WHERE shopid=".$rs['shopid']." ");
		$rs['shopconfig']=$shopconfig;
		$opentype="doing";
		if($shopconfig['opentime']==1)
		{
			$opentype=opentype($shopconfig['starthour'],$shopconfig['startminute'],$shopconfig['endhour'],$shopconfig['endminute']);
		}
		$rs['opentype']=$opentype;
		$isfav=$db->getOne("SELECT shopid FROM ".table('fav_shop')." WHERE userid='".$userid."' AND shopid='".$rs['shopid']."'  ");
		if($isfav)
		{
			
			$rs['isfav']=1;
		}
		$cat=array();
		 
		if($shopconfig['showweek']){
			 $rs['caicat']=$caiModel->getByweek($rs['shopid'],3);
		}else{
			$res2=$db->query("SELECT catid,cname FROM ".table('cai_cat')." WHERE shopid=".$rs['shopid']." ");
			while($rs2=$db->fetch_array($res2))
			{
				$rs2['cailist']=shopcailist($rs['shopid']," AND catid=".$rs2['catid']);
				$cat[]=$rs2;
			}
			$rs['caicat']=$cat;
		}
		
		$shoplist[]=$rs;
	}
	return $shoplist;
}

function getshopinfo($shopid,$smarty=0)
{
	global $db;
	$shop=$db->getRow("SELECT * FROM ".table('shop')." WHERE shopid='$shopid' AND visible>=0    "); 
	$content=$db->getOne("SELECT content FROM ".table('shop_data')." WHERE shopid='$shopid' ");
	$content && $shop['content']=$content;
	if($_SESSION['ssuser']['userid']){
		$isfav=$db->getOne("SELECT shopid FROM ".table('fav_shop')." WHERE userid=".intval($_SESSION['ssuser']['userid'])." AND shopid='$shopid'  ");
	}
	if($isfav)
	{
		$shop['isfav']=1;
	}
	$shopconfig=$db->getRow("SELECT * FROM ".table('shopconfig')." WHERE shopid='$shopid' ");
	$opentype='doing';
	if($shopconfig['opentime']==1)
	{
		$opentype=opentype($shopconfig['starthour'],$shopconfig['startminute'],$shopconfig['endhour'],$shopconfig['endminute']);
	}
	$shop['opentype']=$opentype;
	if($smarty)
	{
		$GLOBALS['smarty']->assign("shop",$shop);
		$GLOBALS['smarty']->assign("shopconfig",$shopconfig);
	}
	 
	return array("shop"=>$shop,"shopconfig"=>$shopconfig);
	
}

?>