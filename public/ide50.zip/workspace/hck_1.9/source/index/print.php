<?php

set_time_limit(120);
session_write_close();
require_once ROOT_PATH.'api/print/dsprint_api_php/dsprint.class.php';
require_once ROOT_PATH.'api/print/dsprint_api_php/dsconfig.class.php';
require_once ROOT_PATH.'api/print/dsprint_api_php/shop_config.php';
header("Content-Type:text/html;charset=UTF-8");

if(get('a')=='changeurl'){
	$shopid=get('shopid','i');
	$client = new DsPrintSend($dyconfig[$shopid]['password'],$dyconfig[$shopid]['app_id']);
	//更改URL
	echo $client->changeurl();
	exit;	
}

$id=get('id','i');
$order=$db->getRow("select * from ".table('order')." where id=".$id." ");
if( empty($order)){
	exit('出错了');
}
$shop=$db->getRow("select * from ".table('shop')." WHERE shopid=".$order['shopid']." ");
if(empty($shop) or empty($order)){
	exit('出错了');
}
$shopid=$shop['shopid'];
$sql="select oc.*,c.title,c.price from ".table('order_cai')." as oc left join ".table('cai')." as c on oc.caiid=c.id where oc.orderid='$id'  ";
$cailist=$GLOBALS['db']->getAll($sql);
$strcai="";
foreach($cailist as $v){
	$strcai.=$v['title'].$v['cainum']."份,￥".$v['price']."元\n";
}

$freeTxt = "\n**订餐网\n" .
					"订单时间：".date("Y-m-d H:i:s",$order['dateline'])."\n".
					"订单号码：".$order['orderno']."\n" .
					"\x1B\x21\x08".#打印机粗体指令
					"姓名：".$order['orderuser']."\n" .
					"手机：".$order['orderphone']."\n".
					"地址：".$order['orderaddress']."\n".
					"特殊要求：".$order['orderinfo']."\n" .
					"金额：".$order['money']."\n".
					$strcai.
					"\x1B\x21\x00";#取消打印机粗体指令
 
$client = new DsPrintSend($dyconfig[$shopid]['password'],$dyconfig[$shopid]['app_id']);
//$client = new DsPrintSend();
//打印字符串，此处修改为用户名下对应的在线的且连接打印机的dtuid。

echo $client->printtxt($dyconfig[$shopid]['dtuid'],$freeTxt,60);
?>