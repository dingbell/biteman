<?php
if(!defined("CT"))
{
	die("IS WRONG");
}
//载入模型
loadModel(array('cai'));
$userid=intval($_SESSION['ssuser']['userid']);
$smarty->assign("shopnum",$db->getOne("SELECT count(1) FROM ".table("shop")." "));
$smarty->assign("cainum",$db->getOne("SELECT count(1) FROM ".table('cai')." "));
//调用收藏
$favshops=$db->getCols("SELECT shopid FROM ".table('fav_shop')." WHERE userid=".$userid." AND siteid='$cksiteid' ");
$smarty->assign("favshops",$favshops);
//调用购物车信息

$shopcarinfo=shopcarinfo();
$smarty->assign("shopcart",$shopcarinfo['shoplist']);
$smarty->assign("totalmoney",$shopcarinfo['totalmoney']);
//店铺列表
$provinceid=intval($_COOKIE['selectarea']['provinceid']);
if($provinceid && !$db->getRow("select * from ".table('province')." WHERE provinceid=".intval($provinceid)." AND siteid=".$cksiteid." ")){
	$provinceid=0;
}
$cityid=intval($_COOKIE['selectarea']['cityid']);
if($cityid && !$db->getRow("select * from ".table('city')." WHERE cityid=".intval($cityid)." AND siteid=".$cksiteid." ")){			
	$_GET['cityid']=$cityid=0;
}
$townid=intval($_COOKIE['selectarea']['townid']);
if($townid && !$db->getRow("select * from ".table('town')." WHERE townid=".intval($townid)." AND siteid=".$cksiteid." ")){			
	$townid=0;
}
$shoplist=array();
$pagesize=5;
$page=max(1,intval($_GET['page']));
$page=min($page,100);
$start=($page-1)*$pagesize;
//选择店铺sql
$w=" siteid='$cksiteid'  AND  visible=0 ";
if($provinceid){
	$w.=" AND provinceid=".$provinceid;
}
if($cityid){
	$w.=" AND cityid=".$cityid;
}
if($townid){
	$w.=" AND townid=".$townid;
}

//End 店铺
if($favshops)
{
	$rscount=$db->getOne("SELECT COUNT(*) FROM ".table('fav_shop')." WHERE userid='$userid' AND siteid='$cksiteid'   ");
	$shopids=$db->getCols("SELECT shopid FROM ".table('fav_shop')." WHERE userid='$userid' AND siteid='$cksiteid'    LIMIT $start,$pagesize   ");
	$sql="SELECT s.* FROM   ".table('shop')." s  WHERE shopid in(".implode(",",$shopids).") AND siteid='$cksiteid' AND s.visible=0 LIMIT $start,$pagesize ";
	$favshoplist=shoplist($sql);;
}
//更多店
$sql="SELECT * FROM  ".table('shop')." WHERE ".$w."  AND isrecommend=0 ORDER BY shopid DESC  LIMIT 48 ";

$shoplist=shoplist($sql);
$sql="SELECT * FROM  ".table('shop')." WHERE ".$w."  AND isrecommend=1 ORDER BY shopid DESC  LIMIT 24 ";
 
$tjshoplist=shoplist($sql);
$smarty->assign(array(
	"favshoplist"=>$favshoplist,
	"shoplist"=>$shoplist,
	"tjshoplist"=>$tjshoplist
));
/*留言板*/
$guestlist=$db->getAll("SELECT * FROM ".table('guest')." WHERE status=1 AND siteid='$cksiteid' ORDER BY id DESC LIMIT 10 ");
$smarty->assign("guestlist",$guestlist);

$smarty->assign("seo",$seo);
if($userid){
	$day=date("Y-m-d");
	$smarty->assign("isqiandao",$db->getOne("SELECT id FROM ".table('qiandao')." WHERE userid='$userid' AND day='$day' "));	
}

$smarty->display("index.html");

?>