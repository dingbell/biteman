<?php
$smarty->display("promote.html");
?>