<?php
$smarty->display("help.html");
?>