<?php
$a=get('a','h');
$a=$a?$a:"index";
switch($a){
	case "index":
			$smarty->display("weixin_sucai/index.html");
		break;
	case "show":
			$id=get_post('id','i');
			$data=$db->getRow("SELECT * FROM ".table('weixin_sucai')." WHERE id=".$id." ");
			$weixin=$db->getRow("SELECT * FROM ".table('weixin')." WHERE id=".intval($data['wid'])." ");
			$smarty->assign(array(
				"data"=>$data,
				"weixin"=>$weixin
			));
			$smarty->display("weixin_sucai/show.html");
		break;
}

?>