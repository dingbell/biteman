<?php

$_GET['a']=$_GET['a']?htmlspecialchars($_GET['a']):'index';
$content='asdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额qasdadasdad阿四大四大上达到阿四大四大上大声大声道去委屈委屈委屈委屈委屈委屈委屈委屈额q';
switch($_GET['a'])
{
	case 'index':
			echo '测试数据：<br>
			<a href="index.php?m=test&a=shop" target="_blank">添加商店</a><br>
			<a href="index.php?m=test&a=user" target="_blank">添加用户</a><br>
			<a href="index.php?m=test&a=order" target="_blank">添加订单</a><br>
			<a href="index.php?m=test&a=delcai" target="_blank">删除美食</a><br>
			<a href="index.php?m=test&a=shopadmin" target="_blank">商店管理员</a><br>
			<a href="index.php?m=test&a=guest" target="_blank">留言管理</a><br>
			<a href="index.php?m=test&a=comment" target="_blank">评论测试</a><br>
			<a href="index.php?m=test&a=art" target="_blank">文章测试</a><br>
			<a href="index.php?m=test&a=goods" target="_blank">积分商品测试</a><br>
			<a href="index.php?m=test&a=goodsorder" target="_blank">积分商品订单测试</a><br>
			<a href="index.php?m=test&a=showtable" target="_blank">显示表属性</a>
			';
		break;
	case 'shop':
		for($i=0;$i<100;$i++)
		{
			$db->query("INSERT INTO ".table('shop')." SET shopname='test".time()."',content='$content' ");
			$shopid=$db->insert_id();
			for($j=0;$j<5;$j++)
			{
				$db->query("INSERT INTO ".table('cai_cat')." SET shopid='$shopid',cname='test".time()."' " );
				$catid=$db->insert_id();
				for($k=0;$k<10;$k++)
				{
					$db->query("INSERT INTO ".table('cai')." SET shopid='$shopid',catid='$catid',title='test".time()."' ");
				}
			}
			
		}
		$_SESSION['test']['shop']=intval($_SESSION['test']['shop'])+100;
		echo "已添加".$_SESSION['test']['shop']." ";
		sleep(1);
		echo "<script>location.href='index.php?m=test&a=shop';</script>";
	break;

	case 'user':
			for($i=0;$i<1000;$i++)
			{
				$db->query("INSERT INTO ".table('user')." SET user='test".time()."',nickname='test".time()."',password='".umd5(1234567)."' ");
			}
			$_SESSION['test']['user']=intval($_SESSION['test']['user'])+1000;
			echo "已添加".$_SESSION['test']['user']." ";
			sleep(1);
			echo "<script>location.href='index.php?m=test&a=user';</script>";
		break;
	case 'order':
			for($i=0;$i<1000;$i++)
			{
				$db->query("INSERT INTO ".table('order')." SET orderno='test".time()."',orderphone='12121212',orderaddress='axxxxxxxxxxxxxxxx阿四大四大爱的阿斯达aaaaaaaaaa',isvalid=1 ");
			}
			$_SESSION['test']['order']=intval($_SESSION['test']['order'])+1000;
			echo "已添加".$_SESSION['test']['order']." ";
			sleep(1);
			echo "<script>location.href='index.php?m=test&a=order';</script>";
		break;
	case 'delcai':
			$db->query("DELETE FROM ".table('cai')." ORDER BY id DESC LIMIT 10000 " );
			echo '正在删除';
			sleep(1);
			echo "<script>location.href='index.php?m=test&a=delcai';</script>";
		break;
	case 'shopadmin':
		for($i=0;$i<1000;$i++)
		{
			$db->query("INSERT INTO ".table('shopadmin')." SET siteid=1,shopid=50000,adminname='test1212',password='".umd5(1234567)."'  ");
		}
		$_SESSION['test']['shopadmin']=intval($_SESSION['test']['shopadmin'])+1000;
			echo "已添加".$_SESSION['test']['shopadmin']." ";
			sleep(1);
			echo "<script>location.href='index.php?m=test&a=shopadmin';</script>";
		break;
	case 'guest':
		for($i=0;$i<1000;$i++)
		{
			$db->query("INSERT INTO ".table('guest')." SET siteid=1,shopid=50000,title='test1212',content='$content'  ");
		}
		$_SESSION['test']['guest']=intval($_SESSION['test']['guest'])+1000;
			echo "已添加".$_SESSION['test']['guest']." ";
			sleep(1);
			echo "<script>location.href='index.php?m=test&a=guest';</script>";
		break;
	case 'comment':
		for($i=0;$i<1000;$i++)
		{
			$db->query("INSERT INTO ".table('cai_comment')." SET siteid=1,shopid=50000,pid=123,userid=400,dateline=".time().",content='$content',status=1 ");
		}
		$_SESSION['test']['comment']=intval($_SESSION['test']['comment'])+1000;
		echo "已添加".$_SESSION['test']['comment']." ";
		sleep(1);
		echo "<script>location.href='index.php?m=test&a=comment';</script>";
	break;
	
	case 'art':
		for($i=0;$i<1000;$i++)
		{
			$db->query("INSERT INTO ".table('art')." SET siteid=1,shopid=50000,userid=400,dateline=".time().",title='测试".time()."' ");
		}
		$_SESSION['test']['art']=intval($_SESSION['test']['art'])+1000;
		echo "已添加".$_SESSION['test']['art']." ";
		sleep(1);
		echo "<script>location.href='index.php?m=test&a=art';</script>";
	break;
	
	case 'goods':
			for($j=0;$j<100;$j++)
			{
				$db->query("INSERT INTO ".table('goods_cat')." SET  cname='test".time()."' " );
				$catid=$db->insert_id();
				for($k=0;$k<10;$k++)
				{
					$db->query("INSERT INTO ".table('goods')." SET  catid='$catid',title='test".time()."' ");
				}
			}
			$_SESSION['test']['goods']=intval($_SESSION['test']['goods'])+100;
			echo "已添加".$_SESSION['test']['goods']." ";
			sleep(1);
			echo "<script>location.href='index.php?m=test&a=goods';</script>";
		break;
	case 'goodsorder':
			for($j=0;$j<1000;$j++)
			{
				$db->query("INSERT INTO ".table('goods_order')." SET orderno='test".time()."',phone='12121212',address='axxxxxxxxxxxxxxxx阿四大四大爱的阿斯达aaaaaaaaaa',isvalid=1,dateline=".time()." " );

			}
			$_SESSION['test']['goodsorder']=intval($_SESSION['test']['goodsorder'])+1000;
			echo "已添加".$_SESSION['test']['goodsorder']." ";
			sleep(1);
			echo "<script>location.href='index.php?m=test&a=goodsorder';</script>";
		break;
	case 'showtable':
			$arr=$db->getAll("show tables");
			$tables=array();
			foreach($arr as $a){
				foreach($a as $v)
				{
					
				 
					$t=$db->getAll("SHOW COLUMNS FROM  $v ");
					echo "表 ".str_replace("hck_","",$v)." 属性列表:   ";
					foreach($t as $kv)
					{
						echo $kv[Field] .",";
					}
					echo "<br>";
				}
			}
			
			
		 
		break;
}

?>