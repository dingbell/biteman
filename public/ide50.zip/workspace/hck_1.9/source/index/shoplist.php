<?php
if(!defined("CT"))
{
	die("IS WRONG");
}
$_GET['a']=$_GET['a']?htmlspecialchars(trim($_GET['a'])):'index';
switch($_GET['a'])
{
	case 'index':
		$userid=intval($_SESSION['ssuser']['userid']);
		//初始化 区域
		if(isset($_GET['provinceid'])){
			$provinceid=get('provinceid','i');
			setcookie("selectarea[provinceid]",$provinceid,time()+3600*24*360);
			setcookie("selectarea[cityid]",0,time()-10);
			setcookie("selectarea[townid]",0,time()-10);
		}else{
			$_GET['provinceid']=$provinceid=intval($_COOKIE['selectarea']['provinceid']);
		}
		if(!$province=$db->getRow("select * from ".table('province')." WHERE provinceid=".intval($provinceid)." AND siteid=".$cksiteid." ")){
			$_GET['provinceid']=$provinceid=0;
		}
		
		if(isset($_GET['cityid'])){
			$cityid=get('cityid','i');
			setcookie("selectarea[cityid]",$cityid,time()+3600*24*360);
			setcookie("selectarea[townid]",0,time()-10);
		}else{
			$provinceid && 	$_GET['cityid']=$cityid=intval($_COOKIE['selectarea']['cityid']);
		}
		
		if(!$city=$db->getRow("select * from ".table('city')." WHERE cityid=".intval($cityid)." AND siteid=".$cksiteid." ")){			
				$_GET['cityid']=$cityid=0;
		}
		
		if(isset($_GET['townid'])){
			$townid=get('townid','i');
			setcookie("selectarea[townid]",$townid,time()+3600*24*360);
		}else{
			$cityid && $_GET['townid']=$townid=intval($_COOKIE['selectarea']['townid']);
		}
		
		if(!$town=$db->getRow("select * from ".table('town')." WHERE townid=".intval($townid)." AND siteid=".$cksiteid." ")){			
				$_GET['townid']=$townid=0;
		}
		
		//区域选择
		$provinces=provinces($cksiteid);
		$smarty->assign("provinces",$provinces);
		if($provinceid)
		{			
			$citys=citys($provinceid);
			$towns=towns(intval($cityid));
			$smarty->assign("citys",$citys);
			$smarty->assign("towns",$towns);
			
		}
		//店铺类目
		if(isset($_GET['catid'])){
			$_GET['catid']=intval($_GET['catid']);
			setcookie("catid",$_GET['catid'],time()+3600*24*360);
		}else{
			$_GET['catid']=intval($_COOKIE['catid']);
		}
		
		$catlist=$db->getAll("SELECT * FROM ".table('shop_cat')."  ORDER BY orderindex ASC ");
		$smarty->assign("catlist",$catlist);
		//起送金额
		if(isset($_GET['smid'])){
			$_GET['smid']=intval($_GET['smid']);
			setcookie("smid",$_GET['smid'],time()+3600*24*360);
		}else{
			$_GET['smid']=intval($_COOKIE['smid']);
		}
		$smlist=$db->getAll("SELECT * FROM ".table('shop_sendmoney')." ORDER BY orderindex ASC ");
		if($_GET['smid']){
			$smname=$db->getRow("SELECT * FROM ".table('shop_sendmoney')." WHERE smid=".$_GET['smid']." ");
		}
		$smarty->assign("smlist",$smlist);
		//平均消费
		$_GET['amid']=intval($_GET['amid']);
		$amlist=$db->getAll("SELECT * FROM ".table('shop_avgmoney')." ORDER BY orderindex ASC ");
		$smarty->assign("amlist",$amlist);
		extract($_GET);
		$sw="";
		if($_GET['catid'])
		{
			$cname=$db->getOne("SELECT cname FROM ".table('shop_cat')."  WHERE catid=".intval($_GET['catid']));
			$seo['title'].="-".$cname;
			$seo['keywords'].=",".$cname;
			$seo['description'].=",".$cname;
			$sw.=" AND s.catid=".intval($_GET['catid'])." ";
		}
		//区域结束
		
		$shopids=array();
		if($provinceid)
		{
			$sw.=" AND s.provinceid=".$provinceid." ";
			$seo['title'].="-".$provinces[$provinceid]['province'];
			$seo['keywords'].=",".$provinces[$provinceid]['province'];
			$seo['description'].=",".$provinces[$provinceid]['province'];
			if(intval($cityid))
			{
				$sw.=" AND s.cityid=".intval($cityid)." ";
				$seo['title'].="-".$citys[$cityid]['city'];
				$seo['keywords'].=",".$citys[$cityid]['city'];
				$seo['description'].=",".$citys[$cityid]['city']; 
				if($townid)
				{
					$sw.=" AND s.townid=".$townid." ";
					$seo['title'].="-".$towns[$townid]['town'];
					$seo['keywords'].=",".$towns[$townid]['town'];;
					$seo['description'].=",".$towns[$townid]['town'];;
				}
				
			}
			
		}
		
		
		if($amid)
		{
			$sw.=" AND s.amid=$amid ";
		}
		if($smid)
		{
			$sw.=" AND s.smid=$smid ";
		}
		
		$order='';
		$_GET['orderby']=isset($_GET['orderby'])?htmlspecialchars(trim($_GET['orderby'])):'orders';
		switch($_GET['orderby'])
		{
			case 'orders ':
					$order=" ORDER BY s.orders DESC";
				break;
			
			case 'new':
					$order=" ORDER BY s.shopid DESC ";
				break;
			
			default :
					$order="ORDER BY s.orders DESC ";
				break;
		}
		
		$smarty->assign("shopnum",$shopnum=$db->getOne("SELECT count(*) FROM ".table("shop")." s    WHERE s.siteid='$cksiteid' AND s.visible=0 $sw "));
		
		
		//调用收藏
		$favshops=$db->getCols("SELECT shopid FROM ".table('fav_shop')." WHERE userid=".$userid." ");
		//调用购物车信息
		$shopcarinfo=shopcarinfo();
		
		$smarty->assign("shopcart",$shopcarinfo['shoplist']); 
		$smarty->assign("totalmoney",$shopcarinfo['totalmoney']);
		$pagesize=ISWAP?12:21;
		$page=max(1,intval($_GET['page']));
		$start=($page-1)*$pagesize;
		$sql="SELECT s.*,c.opentime,c.starthour,c.endhour,c.startminute,c.endminute,c.showweek,c.minprice FROM ".table('shop')." s  LEFT JOIN ".table('shopconfig')." c ON s.shopid=c.shopid WHERE s.siteid='$cksiteid' AND s.visible=0 $sw  $order  LIMIT $start,$pagesize ";
		
		$shoplist=shoplist($sql);
		$smarty->assign("shoplist",$shoplist);
		$smarty->assign("pagelist",multipage($shopnum,$pagesize,$page,"index.php?m=shoplist&provinceid=$provinceid&cityid=$cityid&townid=$townid&catid=$catid&smid=$smid&amid=$amid&orderby=".$_GET['orderby']));
		
		//seo项
		if($page){
			$seo['title'] .="第{$page}页";
			$seo['keywords'].="第{$page}页";
			$seo['description'].="第{$page}页";
		}
		$smarty->assign(array(
			"seo"=>$seo,
			"town"=>$town['town'],
			"city"=>$city['city'],
			"province"=>$province['province'],
			"cname"=>$cname,
			"smname"=>$smname['cname']
		));
		$smarty->display("shoplist.html");
	break;
	case "ajaxcitys":
			$provinceid=get_post("provinceid","i");
			$data=$db->getAll("SELECT * FROM ".table('city')." WHERE provinceid=".$provinceid." ");
			echo json_encode($data);
		break;
	case "ajaxtowns":
			$cityid=get_post("cityid","i");
			$data=$db->getAll("SELECT * FROM ".table('town')." WHERE townid=".$cityid." ");
			echo json_encode($data);
		break;	
}

?>