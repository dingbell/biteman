<?php
$a=get('a','h');
$a=$a?$a:"index";
require(ROOT_PATH."config/table.php");
$type_id_list=$table_weixin_command['type_id_list'];
$weixin=$db->getRow("select * from ".table('weixin')." WHERE shopid=".SHOPID." ");
if(empty($weixin)) gourl("shopadmin.php?m=weixin");
switch($a){
	case "index":
			assignlist("weixin_command",60," AND shopid=".SHOPID." ");
			$smarty->assign(array(
				"type_id_list"=>$type_id_list,
			));
			$smarty->display("weixin_command/index.html");
		break;
	case "add":
			$id=get('id','i');
			$data=$db->getRow("SELECT * FROM ".table('weixin_command')." WHERE id=".$id." "); 
			$smarty->assign(array(
				"data"=>$data,
				"type_id_list"=>$type_id_list,
			));
			$smarty->display("weixin_command/add.html");
		break;
	case "save":
			$id=get_post("id","i");
			$data["wid"]=$weixin['id'];
			$data["title"]=get_post("title","h");
			$data["command"]=get_post("command","h");
			$data["type_id"]=get_post("type_id","i");
			$data["content"]=get_post("content","h");
			$data["dateline"]=time();
			$data["siteid"]=SITEID;
			$data["shopid"]=SHOPID;
			$data["sc_id"]=get_post("sc_id","i");
			if($id){
				$db->update("weixin_command",$data," AND id=$id");
			}else{
				$db->insert("weixin_command",$data);
			}
			errback("保存成功");
		break;
	case "delete":
		
		break;
}


?>