<?php
$a=get('a','h');
$a=$a?$a:"index";
$weixin=$db->getRow("select * from ".table('weixin')." WHERE shopid=".SHOPID." ");
if(empty($weixin)) gourl("shopadmin.php?m=weixin");
switch($a){
	
	case "index":
			assignlist("weixin_user",40," AND wid=".$weixin['id']);
			$smarty->display("weixin_user/index.html");
		break;
		
	case "add":
	
		break;
	
}

?>