<?php
$smarty->display("foot.html");
?>