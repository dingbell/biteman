<?php
$smarty->display("index.html");
?>