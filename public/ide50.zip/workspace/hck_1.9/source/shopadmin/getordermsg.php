<?php

check_login();
//获取系统消息
$shopid=intval($_SESSION['adminshop']['shopid']);
$msg=$db->getRow("select * FROM ".table('sysmsg_shop')." WHERE shopid=$shopid order by id DESC limit 1 ");
$w="";
if($msg){
	$w=" AND id>".$msg['msgid'];
}
$data=$db->getAll("SELECT id  FROM ".table('sysmsg')." WHERE start_time<".time()." AND end_time >".time()." AND type_id in(1,3) AND status=1 $w ");

if($data){
	foreach($data as $k=>$v){
		$db->insert("sysmsg_shop",array(
			"shopid"=>$shopid,
			"msgid"=>$v['id'],
			"status"=>0,
			"dateline"=>time()
		));
	}
}

$num=$db->getOne("SELECT COUNT(*) FROM ".table('order')." WHERE sendtype=0 AND shopid='$shopid' AND isvalid=1 ");
if($num)
{
	echo 1;
}

?>