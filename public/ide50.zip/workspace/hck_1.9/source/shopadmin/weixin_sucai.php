<?php
$a=get('a','h');
$a=$a?$a:"index";
$weixin=$db->getRow("select * from ".table('weixin')." WHERE shopid=".SHOPID." ");
if(empty($weixin)) gourl("shopadmin.php?m=weixin");
switch($a){
	
	case "index":
			assignlist("weixin_sucai",20," AND pid=0 AND shopid=".SHOPID." ");
			$smarty->display("weixin_sucai/index.html");
		break;
	case "add":
			$id=get('id','i');
			$data=$db->getRow("SELECT * from ".table('weixin_sucai')." WHERE id=".$id." AND shopid=".SHOPID." ");
			if($data){
				$child=$db->getAll("select * from ".table('weixin_sucai')." WHERE pid=".$id." ");
				if($child){
					$data['child']=$child;
				}
			}
			$smarty->assign(array(
				"data"=>$data
			));
			$smarty->display("weixin_sucai/add.html");
		break;
	case "addiframe":
			$id=get('id','i');
			$data=$db->getRow("SELECT * from ".table('weixin_sucai')." WHERE id=".$id." AND shopid=".SHOPID." ");
			$smarty->assign(array(
				"data"=>$data,
				"pid"=>get('pid','i'),
			));
			$smarty->display("weixin_sucai/addiframe.html");
		break;
	case "save":
		$id=get_post("id","i");
		$data["title"]=get_post("title","h");
		$data["dateline"]=time();
		
		$data["content"]=get_post("content","h");
		$data["status"]=get_post("status","i");
		
		$data["imgurl"]=get_post("imgurl","h");
		$data['wid']=$weixin['id'];
		$data['description']=get_post('description','h');
		$data['linkurl']=get_post('linkurl','h');
		if($id){
			$db->update("weixin_sucai",$data," AND id=".$id);
		}else{
			$data["siteid"]=SITEID;
			$data["pid"]=get_post("pid","i");
			$data['shopid']=SHOPID;
			$id=$db->insert("weixin_sucai",$data);
		}
		if(get_post('pid','i')){
			echo "<script>window.parent.location='shopadmin.php?m=weixin_sucai&a=add&id=".get_post('pid','i')."';</script>";
		}else{
			echo "<script>window.parent.location='shopadmin.php?m=weixin_sucai&a=add&id=".$id."';</script>";
		}
		break;
	case "delete":
	
		break;	
	
}
?>