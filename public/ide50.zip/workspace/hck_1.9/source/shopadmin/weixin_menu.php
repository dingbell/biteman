<?php
$a=get('a','h');
$a=$a?$a:"index";
$weixin=$db->getRow("select * from ".table('weixin')." WHERE shopid=".SHOPID." ");
if(empty($weixin)) gourl("shopadmin.php?m=weixin");
require(ROOT_PATH."config/table.php");
switch($a){
	
	case "index":
			$data=$db->getAll("SELECT * FROM ".table('weixin_menu')." WHERE wid=".$weixin['id']." ");
			foreach($data  as $k=>$v){
				if($v['pid']==0){
					$ndata[$v['id']]=$v;
				}else{
					$ndata[$v['pid']]['child'][]=$v;
				}
			}
			$smarty->assign(array(
			"data"=>$ndata,
			"w_type_list"=>$table_weixin_menu['type_id_list'],
			"w_key_list"=>$table_weixin_menu['w_key_list']
		));
			$smarty->display("weixin_menu/index.html");
		break;
		
	case "add":
			$id=get('id','i');
			$data=$db->getRow("SELECT * FROM ".table('weixin_menu')." WHERE id=".$id." ");
			$t_d=$db->getAll("SELECT id,title FROM ".table('weixin_menu')." WHERE pid=0 AND wid=".$weixin['id']." ");
			if($t_d){
				foreach($t_d as $v){
					$pid_list[$v['id']]=$v['title'];
				}
			}
			$smarty->assign(array(
				"data"=>$data,
				"pid_list"=>$pid_list,
				"w_type_list"=>$table_weixin_menu['type_id_list'],
				"w_key_list"=>$table_weixin_menu['w_key_list']
			));
			$smarty->display("weixin_menu/add.html");
		break;
	case "save":
			$id=get_post("id","i");
			$data["SITEID"]=SITEID;
 
			$data["wid"]=$weixin['id'];
			$data["pid"]=get_post("pid","i");
			$data["orderindex"]=get_post("orderindex","i");
			$data["title"]=get_post("title","h");
			$data['w_type']=get_post('w_type','h');
			$data['w_key']=post('w_key','h');
			$data['w_url']=post('w_url','h');
			$data['sc_id']=post('sc_id','i');
			$data['content']=post('content','h');
			if($id){
				$db->update("weixin_menu",$data," AND id=".$id."");
			}else{
				$db->insert("weixin_menu",$data);
			}
			errback("保存成功");
		break;
	case "delete":
			$id=get('id','id');
			$db->query("delete from ".table('weixin_menu')." WHERE id=".$id." AND wid=".$weixin['id']." ");
		break;
	case "createmenu":
			$c=file_get_contents("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=".$weixin['appid']."&secret=".$weixin['appkey']."");
		 
			$data=json_decode($c,true);
			$token=$data['access_token'];
			$op=array(
				"where"=>" wid=".$weixin['id']." ",
				"order"=>" pid ASC,orderindex ASC"
			);
			$data=$this->weixin_menu->select($op);
			foreach($data  as $k=>$v){
				if($v['pid']==0){
					$ndata[$v['id']]=array("type"=>$v['w_type'],"name"=>$v['title'],"key"=>$v['w_key'],"url"=>$v['w_url']);
				}else{
					$ndata[$v['pid']]['sub_button'][]=array("type"=>$v['w_type'],"name"=>$v['title'],"key"=>$v['w_key'],"url"=>$v['w_url']);
				}
			}
			$menu=array();
			foreach($ndata as $v){
				$menu[]=$v;
			}
			$menu=zh_json_encode(array("button"=>$menu));
			$res=curl_post("https://api.weixin.qq.com/cgi-bin/menu/create?access_token=".$token,$menu);
			//{"errcode":0,"errmsg":"ok"}
			echo $res;
		break;
	case "deletemenu":
			$c=file_get_contents("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=".$weixin['appid']."&secret=".$weixin['appkey']."");
		 
			$data=json_decode($c,true);
			$token=$data['access_token'];
			$res=file_get_contents("https://api.weixin.qq.com/cgi-bin/menu/delete?access_token=".$token);
			//{"errcode":0,"errmsg":"ok"}
			echo $res;
		break;
}

?>