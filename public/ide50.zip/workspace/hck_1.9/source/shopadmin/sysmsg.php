<?php
//获取系统消息
$shopid=intval($_SESSION['adminshop']['shopid']);
switch($a){
	case "index":
			$limit=10;
			$url="shopadmin.php?m=sysmsg";
			$page=max(1,get('page','i'));
			$start=($page-1)*$limit;
			$data=$db->getAll("select * FROM ".table('sysmsg_shop')." WHERE shopid=$shopid AND status<99 order by id desc LIMIT $start,$limit");
			if($data){
				foreach($data as $k=>$v){
					$d=$db->getRow("SELECT *  FROM ".table('sysmsg')." WHERE id=".$v['msgid']);
					$v['title']=$d['title'];
					$v['content']=$d['content'];
					$data[$k]=$v;
				}
			}
			$rscount=$db->getOne("select count(*) from ".table('sysmsg_shop')." WHERE shopid=$shopid AND status<99 ");
			$smarty->assign(array(
				"data"=>$data,
				"rscount"=>$rscount,
				"pagelist"=>multipage($rscount,$limit,$page,$url)
			));
			$smarty->display("sysmsg/index.html");
		break;
	case "show":
			$id=get('id','i');
			$data=$db->getRow("SELECT * FROM ".table('sysmsg_shop')." WHERE id=$id AND shopid=$shopid ");
			if($data){
				$d=$db->getRow("SELECT *  FROM ".table('sysmsg')." WHERE id=".$data['msgid']);
				$data['title']=$d['title'];
				$data['content']=$d['content'];
				if($data['status']==0){
					$db->update("sysmsg_shop",array("status"=>1)," AND id=$id ");
				}
			}
			$smarty->assign(array(
				"data"=>$data
			));
			$smarty->display("sysmsg/show.html");
		break;
	case "delete":
			$id=get_post("id","i");
			$db->update("sysmsg_shop",array("status"=>99)," AND id=$id ");
			errback("删除成功");
		break;
		
}

?>