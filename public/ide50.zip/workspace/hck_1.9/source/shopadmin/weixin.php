<?php
$_GET['a']=$_GET['a']?htmlspecialchars(trim($_GET['a'])):'index';
switch($_GET['a']){
	
	case "index":
	case "add":
			
			$data=$db->getRow("select * from ".table('weixin')." WHERE shopid=".SHOPID." ");
			$smarty->assign("data",$data);
			$smarty->display("weixin/add.html");
		break;
	case "save":
			$id=get_post("id","i");
			$data["token"]=post("token","h");
			$data["title"]=post("title","h");
			$data["dateline"]=time();
			$data['status']=post('status','i');
			$data['imgurl']=post('imgurl','h');
			$data['logo']=post('logo','h');
			$data['imgsdata']=post('imgsdata','x');
			$data['appid']=post('appid','h');
			$data['appkey']=post('appkey','h');
			$data['ysid']=post('ysid','h');
			if($id){
				$db->update("weixin",$data," AND id='$id' ");
			}else{
				$data['siteid']=SITEID;
				$data['shopid']=SHOPID;
				$db->insert("weixin",$data);
			}
			errback("保存成功");
		break;
	case "delete":	
	
	break;
}
?>