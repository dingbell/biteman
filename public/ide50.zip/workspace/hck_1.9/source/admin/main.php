<?php

check_login();
if(file_exists("install.lock"))
{
	$smarty->assign("install","请删除install目录");
}
$daystart=strtotime(date("Y-m-d"));//一天的开始
$dayend=$daystart+86400;//一天的结束
//收入
$smarty->assign("money",floatval($db->getOne("select sum(money) from ".table('order')." where  sendtype=3 AND siteid='$siteid' ")));
$smarty->assign("daymoney",floatval($db->getOne("select sum(money) from ".table('order')." where sendtype=3 and dateline>'$daystart' and dateline<'$dayend'  AND siteid='$siteid' ")));

//订餐数

$smarty->assign("ordernewnum",floatval($db->getOne("select count(*) from ".table('order')." where sendtype=0 AND isvalid=1   AND siteid='$siteid' ")));//新订单
$smarty->assign("ordernum",intval($db->getOne("select count(*) from ".table('order')." where  sendtype=3  AND isvalid=1  AND siteid='$siteid' ")));//订单成交总数
$smarty->assign("orderdaynum",intval($db->getOne("select count(*) from ".table('order')." where sendtype=3 and dateline>'$daystart' and dateline<'$dayend' AND isvalid=1   AND siteid='$siteid' ")));//今日订单成交数
//新留言
$smarty->assign("guestnum",intval($db->getOne("select count(*) from ".table('guest')." where status=0  AND siteid='$siteid' ")));
//新美食评论
$smarty->assign("caicommentnum",intval($db->getOne("select count(*) from ".table('cai_comment')." where status=0   AND siteid='$siteid'")));

//新文章评论
$smarty->assign("artcommentnum",intval($db->getOne("select count(*) from ".table('art_comment')." where status=0  AND siteid='$siteid' ")));
//用户数
$smarty->assign("usernum",intval($db->getOne("select count(*) from ".table('user')." ")));
$smarty->assign("userdaynum",intval($db->getOne("select count(*) from ".table('user')." where dateline>'$daystart' and dateline<'$dayend' ")));


//菜的数量
$smarty->assign("cainum",$db->getOne("select count(*) from ".table('cai')." "));
 
$smarty->assign("ct_version",$smarty->version());
$v=@file_get_contents(ONLINEUPDATE."version.php");
$v=unserialize($v);
if($v[0]<=$smarty->version){
	$version_msg="目前已经是最新版本。";
}else{
	$version_msg="最新版本为{$v[0]},请尽快更新。";
}
$smarty->assign("version_msg",$version_msg);
$smarty->display("main.html");

?>
