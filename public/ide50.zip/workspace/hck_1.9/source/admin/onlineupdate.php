<?php
	switch($a){
		case "index":
				$smarty->assign("ct_version",$smarty->version());
				$v=@file_get_contents(ONLINEUPDATE."version.php");
				$v=unserialize($v);
				if($v[0]==$smarty->version){
					$version_msg="目前已经是最新版本。";
				}else{
					$version_msg="最新版本为{$v[0]},请尽快更新。";
				}
				$smarty->assign("version_msg",$version_msg);
				$smarty->display("onlineupdate.html");
			break;
		case "update":
			set_time_limit(10000);
			$v=file_get_contents(ONLINEUPDATE."version.php");
			$v=unserialize($v);
			asort($v);
			$now=$smarty->version;
			foreach($v as $d){
				if($d>$now){
					updateNow($d);
					$now=$d;
				}
			}
			exit(json_encode(array("error"=>0,"message"=>"success")));
			break;
	}
	function updateNow($d){
		
		file_put_contents(ROOT_PATH."update/update.zip",file_get_contents(ONLINEUPDATE."zip/{$d}.zip"));
		require(ROOT_PATH."includes/cls_pclzip.php");
		$zip = new pclzip(ROOT_PATH."update/update.zip");
		$zip->extract(ROOT_PATH."update");
		file_get_contents("http://".$_SERVER['HTTP_HOST']."/update/index.php?a=update");
		delfile(ROOT_PATH."update");
		return true;
	}
?>