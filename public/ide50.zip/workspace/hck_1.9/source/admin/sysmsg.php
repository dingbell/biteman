<?php
$status_list=array(
	1=>"正常",
	0=>"禁止"
);
$type_list=array(
	1=>"全站",
	2=>"用户",
	3=>"商家",
	
);
switch($a){
	case "index":
			$where="";
			$url="admin.php?m=sysmsg";
			$limit=10;
			$page=max(1,get('page','i'));
			$start=($page-1)*$limit;
			$data=$db->getAll("select * from ".table('sysmsg')." $where order by id desc  limit $start,$limit");
			$rscount=$db->getOne("select count(*) from ".table('sysmsg')." $where ");
			$smarty->assign(array(
				"status_list"=>$status_list,
				"type_list"=>$type_list,
				"data"=>$data,
				"rscount"=>$rscount,
				"pagelist"=>multipage($rscount,$limit,$page,$url)
			));
			$smarty->display("sysmsg/index.html");
		break;
	case "add":
			$id=get_post("id","i");
			if($id){
				$data=$db->getRow("select * from ".table('sysmsg')." WHERE id=$id ");
			}
			$smarty->assign(array(
				"status_list"=>$status_list,
				"type_list"=>$type_list,
				"data"=>$data
			));
			$smarty->display("sysmsg/add.html");
		break;
	case "save":
			$id=get_post("id","i");
			$data["title"]=get_post("title","h");
			$data["status"]=get_post("status","i");
			
			$data["content"]=get_post("content");
			$data["type_id"]=get_post("type_id","i");
			$data["start_time"]=strtotime(get_post("start_time"));
			$data["end_time"]=strtotime(get_post("end_time")); 
			if($id){
				$db->update("sysmsg",$data," AND id=$id");
			}else{
				$data["dateline"]=time();
				$db->insert("sysmsg",$data);
			}
			errback("保存成功");
		break;
	case "delete":
			$id=get_post("id","i");
			$db->delete("sysmsg"," AND id=$id");
			errback("删除成功");
		break;
		
}
?>