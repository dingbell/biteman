<?php
check_login();
$_GET['a']=isset($_GET['a'])?$_GET['a']:'index';
switch($a){
	
	case "index":
	
		break;
	case "check":
	
		break;
	case "update":
			require_once(ROOT_PATH."includes/cls_pclzip.php");
			$file=ROOT_PATH."update/update.zip";
			$update=get('update');
			file_put_contents($file,file_get_contents($update));
			$zip = new pclzip($file);
			$zip->extract(ROOT_PATH."update");
			file_get_contents("http://".$_SERVER['HTTP_HOST']."/update/index.php");
			echo "success";
		break;
	
}

?>