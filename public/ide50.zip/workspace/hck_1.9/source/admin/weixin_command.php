<?php
$a=get('a','h');
$a=$a?$a:"index";
require(ROOT_PATH."config/table.php");
$type_id_list=$table_weixin_command['type_id_list'];
$wid=get_post('wid','i');
$weixin=$db->getRow("select * from ".table('weixin')." WHERE id=".$wid." ");
$smarty->assign("weixin",$weixin);
if(empty($weixin) && in_array($a,array("add","delete","save"))) errback("请选择微信","admin.php?m=weixin");
$wxw="";
if($weixin){
	$wxw="AND wid=".$wid;
}
switch($a){
	case "index":
			assignlist("weixin_command",60," AND siteid=".SITEID." ".$wxw." ");
			$smarty->assign(array(
				"type_id_list"=>$type_id_list,
			));
			$smarty->display("weixin_command/index.html");
		break;
	case "add":
			$id=get('id','i');
			$data=$db->getRow("SELECT * FROM ".table('weixin_command')." WHERE id=".$id." AND wid=".$weixin['id']." "); 
			$smarty->assign(array(
				"data"=>$data,
				"type_id_list"=>$type_id_list,
			));
			$smarty->display("weixin_command/add.html");
		break;
	case "save":
			$id=get_post("id","i");
			$data["title"]=get_post("title","h");
			$data["command"]=get_post("command","h");
			$data["type_id"]=get_post("type_id","i");
			$data["content"]=get_post("content","h");
			$data["dateline"]=time();
			$data["sc_id"]=get_post("sc_id","i");
			if($id){
				$db->update("weixin_command",$data," AND id=$id");
			}else{
				$data["siteid"]=SITEID;			
				$data['wid']=post('wid','i');
				$data['shopid']=$weixin['shopid'];
				$db->insert("weixin_command",$data);
			}
			errback("保存成功");
		break;
	case "delete":
			$id=get_post('id','i');
			$db->query("delete * from ".table('weixin_command')." WHERE id=".$id." ");
		break;
}


?>