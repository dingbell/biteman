<?php
$a=get('a','h');
$a=$a?$a:"index";
switch($a){
	case "add":
			$userid=get('userid','i');
			$user=$db->getRow("select * FROM ".table('user')." WHERE userid=".$userid." "); 
			$smarty->assign(array(
				"user"=>$user
			));
			$smarty->display("recharge/add.html");
		break;
	case "save":
			$userid=post('userid','i');
			$username=post('username','h');
			$user=$db->getRow("select * FROM ".table('user')." WHERE userid=".$userid." ");
			if(empty($user) or $username!=$user['username']) errback("充值用户不存在");
			$money=post('money',"r",1);
			$content=post('content','h');
			$db->insert("user_paylog",array(
				"userid"=>$userid,
				"content"=>$content,
				"money"=>$money,
				"dateline"=>time(),
				"ftype"=>"user",
				"orderno"=>"user_".time()
				
			));
			//处理用户账户金额
			$db->query("update ".table('user')." SET balance=balance+".$money." WHERE userid=".$userid." ");
			errback("人工充值成功");
		break;
	case "searchuser":
			$username=get_post('username','h');
			$user=$db->getRow("SELECT * FROM ".table('user')." WHERE username='".$username."' ");
			if($user){
				echo json_encode(array("error"=>0,"data"=>$user));
			}else{
				echo json_encode(array("error"=>1,"data"=>$user));
			}
			exit;
		break;
	
}
?>
