<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style>
 #menu-frame{ border-right:1px #c6d9e8 solid}
</style>
<title>管理后台</title>
</head>

<frameset rows="70,*,0" framespacing="0" border="0">
  <frame src="admin.php?m=top" id="header-frame" name="header-frame" frameborder="no" scrolling="no">
  <frameset cols="200, *" framespacing="0" border="0" id="frame-body">
    <frame src="admin.php?m=left" id="menu-frame" name="menu-frame" frameborder="no" scrolling="yes">
   
    <frame src="admin.php?m=main" id="main-frame" name="main-frame" frameborder="no" scrolling="yes" >
  </frameset>
  <frame src="admin.php?m=foot" id="foot-frame" scrolling="no" />
</frameset>

<noframes></noframes>
<body></body>
</html>