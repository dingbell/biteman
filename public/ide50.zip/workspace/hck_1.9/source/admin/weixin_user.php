<?php
$a=get('a','h');
$a=$a?$a:"index";
$wid=get_post('wid','i');
$weixin=$db->getRow("select * from ".table('weixin')." WHERE id=".$wid." ");
$smarty->assign("weixin",$weixin);
if(empty($weixin) && !in_array($a,array("index"))) errback("请选择微信","admin.php?m=weixin");
$wxw="";
if($weixin){
	$wxw="AND wid=".$wid;
}
switch($a){
	
	case "index":
			assignlist("weixin_user",40," AND siteid=".SITEID." ".$wxw);
			$smarty->display("weixin_user/index.html");
		break;
		
	case "add":
	
		break;
	
}

?>