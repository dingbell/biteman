<?php
$_GET['a']=$_GET['a']?htmlspecialchars(trim($_GET['a'])):'index';
switch($_GET['a']){
	
	case "index":
			$w=" AND siteid=".SITEID;
			$title=get_post('title','h');
			if($title){
				$w.=" AND title like '%".$title."%' ";
			}
			assignlist("weixin",40,$w);
			$smarty->display("weixin/index.html");
		break;
	case "add":
			$id=get_post("id","i");
			$data=$db->getRow("select * from ".table('weixin')." WHERE id=".$id." ");
			$smarty->assign("data",$data);
			$smarty->display("weixin/add.html");
		break;
	case "save":
			$id=get_post("id","i");
			$data["token"]=post("token","h");
			$data["title"]=post("title","h");
			$data["dateline"]=time();
			$data['status']=post('status','i');
			$data['imgurl']=post('imgurl','h');
			$data['logo']=post('logo','h');
			$data['imgsdata']=post('imgsdata','x');
			$data['appid']=post('appid','h');
			$data['appkey']=post('appkey','h');
			$data['ysid']=post('ysid','h');
			if($id){
				$db->update("weixin",$data," AND id='$id' ");
			}else{
				$data['siteid']=SITEID;
				$db->insert("weixin",$data);
			}
			errback("保存成功");
		break;
	case "delete":	
	
	break;
	case "wxadmin":
			$id=get_post("id","i");
			$weixin=$db->getRow("select * from ".table('weixin')." WHERE id=".$id." ");
			$smarty->assign("weixin",$weixin);
			$smarty->display("left.html");
		break;
}
?>