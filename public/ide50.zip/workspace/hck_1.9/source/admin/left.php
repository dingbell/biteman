<?php
check_login();
$smarty->display("left.html");
?>