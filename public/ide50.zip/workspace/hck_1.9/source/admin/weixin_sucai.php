<?php
$a=get('a','h');
$a=$a?$a:"index";
$wid=get_post('wid','i');
$weixin=$db->getRow("select * from ".table('weixin')." WHERE id=".$wid." ");
$smarty->assign("weixin",$weixin);
if(empty($weixin) && in_array($a,array("add","addiframe","delete","save"))) errback("请选择微信","admin.php?m=weixin");
$wxw="";
if($weixin){
	$wxw="AND wid=".$wid;
}
switch($a){
	
	case "index":
			assignlist("weixin_sucai",20," AND pid=0 AND siteid=".SITEID." ".$wxw." ");
			$smarty->display("weixin_sucai/index.html");
		break;
	case "add":
			$id=get('id','i');
			$data=$db->getRow("SELECT * from ".table('weixin_sucai')." WHERE id=".$id." AND wid=".$wid." ");
			if($data){
				$child=$db->getAll("select * from ".table('weixin_sucai')." WHERE pid=".$id." AND wid=".$wid." ");
				if($child){
					$data['child']=$child;
				}
			}
			$smarty->assign(array(
				"data"=>$data
			));
			$smarty->display("weixin_sucai/add.html");
		break;
	case "addiframe":
			$id=get('id','i');
			$data=$db->getRow("SELECT * from ".table('weixin_sucai')." WHERE id=".$id." AND wid=".$wid." ");
			$smarty->assign(array(
				"data"=>$data,
				"pid"=>get('pid','i'),
			));
			$smarty->display("weixin_sucai/addiframe.html");
		break;
	case "save":
		$id=get_post("id","i");
		$data["title"]=get_post("title","h");
		$data["dateline"]=time();
		
		$data["content"]=get_post("content","x");
		$data["status"]=get_post("status","i");
		$data['description']=get_post('description','h');
		$data["imgurl"]=get_post("imgurl","h");
		$data['linkurl']=get_post('linkurl','h');
		if($id){
			$db->update("weixin_sucai",$data," AND id=".$id);
		}else{
			$data["pid"]=get_post("pid","i");
			$data["siteid"]=SITEID;			
			$data['wid']=post('wid','i');
			$data['shopid']=$weixin['shopid'];
			$id=$db->insert("weixin_sucai",$data);
		}
		if(get_post('pid','i')){
			echo "<script>window.parent.location='admin.php?m=weixin_sucai&a=add&wid=".$wid."&id=".get_post('pid','i')."';</script>";
		}else{
			echo "<script>window.parent.location='admin.php?m=weixin_sucai&a=add&wid=".$wid."&id=".$id."';</script>";
		}
		break;
	case "delete":
		$id=get('id','i');
		$db->query("DELETE * FROM ".table('weixin_sucai')." WHERE id=".$id." ");
		break;	
	
}
?>