<?php
$_CACHE['apps'] = array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'OTHER',
    'name' => '好吃客',
    'url' => 'http://localhost/hck',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
    ),
    'recvnote' => '1',
  ),
  'UC_API' => 'http://localhost/ucenter',
);
