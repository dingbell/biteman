﻿<?php
//新浪微博接口
define("WB_AKEY" , '3878864147' );
define("WB_SKEY" , '7ad0d6717874169c05f5103d98dcd83a' );
define("CALLBACK","http://{$_SERVER['HTTP_HOST']}/index.php?m=sinalogin&a=apilogin");

?>