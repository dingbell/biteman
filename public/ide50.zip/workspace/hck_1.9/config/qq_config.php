<?php
/*
先到http://connect.qq.com
*/
define("APPID",100324455);
define("APPKEY","e3ac2a9124a4d2e593fbef535862859f");
define("CALLBACK","http://www.tiaoshike.com/index.php?m=qqlogin&a=callback");
define("SCOPE","get_user_info,add_share,list_album,add_album,upload_pic,add_topic,add_one_blog,add_weibo");

?>