<?php
$catlist=array(
	"首页店铺",
	"美食",
	"站外",
	"团购"
);

?>