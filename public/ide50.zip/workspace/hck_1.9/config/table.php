<?php
$table_weixin_command['type_id_list']=array(
	1=>"首次关注",
	2=>"帮助说明",
	3=>"自定义",
	4=>"美食搜索",
	5=>"菜谱搜索",
);

$table_weixin_menu['type_id_list']=array(
			"click"=>"点击",
			"view"=>"网址",
);

$table_weixin_menu['w_key_list']=array(
	"wxclick"=>"一级无回复",
	"wxclick_0"=>"自定义",
	"wxclick_1"=>"今日美食",
	"wxclick_2"=>"菜谱推荐",
	"wxclick_3"=>"店铺推荐",
	"wxclick_4"=>"热门资讯",
	"wxclick_5"=>"最新活动",
	"wxclick_6"=>"最新团购",
);

?>