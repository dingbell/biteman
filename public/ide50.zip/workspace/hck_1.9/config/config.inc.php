<?php 
define("MYSQL_HOST","localhost");
define("MYSQL_USER","root");
define("MYSQL_PWD","123");
define("MYSQL_DB","hck");
define("MYSQL_CHARSET","utf8");
define("TABLE_PRE","hck_");
define("ADMIN_DIR","admin");
define("DOMAIN","hck.skymvc.com");
define("WAPURL","wap.hck.com");
define("SKINS","default");
define("BINDUC",0);

?>