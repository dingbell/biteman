<?php
define("CT",1);
/*取得根目录所在路径*/
error_reporting(0);
if(!file_exists("config/install.lock"))
{
	header("Location: install/");
}
define("IMG_SITE","http://".$_SERVER['HTTP_HOST']."/");//"http://".DOMAIN);
date_default_timezone_set('PRC');  //设置默认时区
define('ROOT_PATH',  str_replace('\\', '/', dirname(__FILE__))."/");
//引入配置文件
require_once(ROOT_PATH."config/config.inc.php");//数据库配置
@ini_set("session.cookie_domain", DOMAIN);
require_once(ROOT_PATH."config/lib_config.php");//常用配置
/*载入公共库文件*/
require_once(ROOT_PATH."includes/lib_base.php");
require_once(ROOT_PATH."includes/lib_safe.php");
require_once(ROOT_PATH."includes/cls_db.php");//引入数据库文件
$db=new Db_class(MYSQL_HOST,MYSQL_USER,MYSQL_PWD,MYSQL_DB,MYSQL_CHARSET);
if(get('setsite')){
	$city=get('city','h');
	if($site=$db->getRow("SELECT siteid,sitename,lat,lng,domain FROM ".table('sites')." WHERE sitename like '%".str_replace(array("市","县"),"",$city)."%' ")){
		$cksiteid=$site['siteid'];
	}else{//设定默认siteid
		$cksiteid=1;
	}
	setcookie("cksiteid",intval($cksiteid),time()+3600*24*360,'/',DOMAIN);
	header("Location: /index.php");
	exit;
}
require_once(ROOT_PATH."includes/cls_model.php");
/*开启数据库存储session
require_once(ROOT_PATH."includes/cls_session.php");
$session=new session($db,3600);
*/
session_start();
require_once(ROOT_PATH."includes/cls_smarty.php");//引入模板文件
$smarty=new Smarty();
$smarty->caching=true;
$smarty->cache_lifetime = 3600;
$smarty->charset="utf-8";
if(empty($skins))
{
	$skins="default";
}

if($_GET['skins'] )
{
	$_SESSION['skins']=$_GET['skins'];
}
if($_SESSION['skins'])
{
	$skins=$_SESSION['skins'];
}else
{
	$skins=SKINS;
}
if(empty($skins))
{
	$skins="default";
}

if( $_SERVER['SERVER_NAME']==WAPURL   or $skins=="wap" or $skins=="phone" or is_mobile() )
{
	if(!defined("ISWAP"))
	{
 		define("ISWAP",true);
	}
	$skins="wap";
}else
{
	define("ISWAP",false);
}
$smarty->cache_dir      = ROOT_PATH . 'temp/caches';
$smarty->compile_dir    = ROOT_PATH . 'temp/compiled';

$smarty->template_dir   = ROOT_PATH . "themes/{$skins}";
$sitelist=$db->getAll("select * from ".table('sites')." order by orderindex asc ");
$smarty->assign("sitelist",$sitelist);
$smarty->display("site.html");
?>