<?php exit;?>a:3:{s:8:"template";a:1:{i:0;s:35:"G:/www/hck/themes/default/test.html";}s:7:"expires";i:1355930435;s:8:"maketime";i:1355926835;}<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<title>�ޱ����ĵ�</title>
</head>
<body>
1355926835aa
</body>
</html>
