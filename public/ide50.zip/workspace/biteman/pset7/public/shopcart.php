if(!defined("CT"))
{
	die("IS WRONG");
}
loadModel(array("user","food"));
$_GET['a']=isset($_GET['a'])?htmlspecialchars($_GET['a']):'index';
$shopid=intval($_GET['shopid']);
loadModel('shop');
 
switch($_GET['a'])
{
	case 'index':
		header("Content-type:text/html;charset=utf-8");
		//增加点击率
		$shopModel->addClick($shopid);
		$userid=intval($_SESSION['ssuser']['userid']);
		//调用购物车信息
		$shopcarinfo=shopcarinfo($shopid);
		$smarty->assign("totalmoney",$shopcarinfo['totalmoney']);
		$smarty->assign("shopcart",$shopcarinfo['shoplist']);
		$isfav=$db->getOne("SELECT shopid FROM ".table('fav_shop')." WHERE userid='$userid' AND shopid='$shopid'  ");
		
		$cat=array();
		$shop=$db->getRow("SELECT * FROM ".table('shop')." WHERE shopid='$shopid' AND siteid='$cksiteid' AND visible=0    ");
		if(!$shop)
		{
			errback("店铺不存在或者已经禁止",'index.php');
		}
}
