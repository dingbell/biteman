<!DOCTYPE HTML>
<html> 
<body>

<form action="make_order.php" method="post">
<input type="text" name="name"><br>
<input type="text" name="email"><br>
<input type="submit">
</form>

</body>
</html>