<?php

    // configuration
    require("../includes/config.php"); 
    
    // define $posiitons, the informtion for protfolio
   // $id =  CS50::query("SELECT id from users WHERE username = ?", $_SESSION["id"]);
    $rows = CS50::query("SELECT * FROM portfolios WHERE user_id = ?", $_SESSION["id"]);
    $positions = [];
    foreach ($rows as $row)
    {
        $stock = lookup($row["symbol"]);
        if ($stock !== false)
        {
            $positions[] = [
                "name" => $stock["name"],
                "price" => $stock["price"],
                "shares" => $row["shares"],
                "symbol" => $stock["symbol"],
                "total" => $row["shares"] * $stock["price"]
            ];
        }
    }
    $cashRows = CS50::query("SELECT cash FROM users where id = ?", $_SESSION["id"]);
    if (count($cashRows) != 0){
        $cash = $cashRows[0]["cash"];
        $positions[] = [
            "symbol" => "CASH",
            "total" => $cash,
            "name" => "",
            "price" => "",
            "shares" => ""
        ];    
    }
    
    // render portfolio
    render("portfolio.php",["positions" => $positions, "title" => "Portfolio"]);
?>
