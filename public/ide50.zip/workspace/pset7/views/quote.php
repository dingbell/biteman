<p>
    A share of <?= htmlspecialchars($name) ?> (<?= htmlspecialchars($symbol) ?>) costs <strong>$<?=number_format($price, 2) ?></strong>
</p>
